package com.dicoding.storyapp.data.response

data class ResponseError(
    val error: Boolean? = null,

    val message: String? = null
)