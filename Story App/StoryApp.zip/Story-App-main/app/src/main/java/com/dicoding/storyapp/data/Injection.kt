package com.dicoding.storyapp.data

import android.content.Context
import com.dicoding.storyapp.data.api.ApiConfig

object Injection {


    fun provideRepository(context: Context): UserRepository {


        val apiService = ApiConfig.getApiService()


        val pref = com.dicoding.storyapp.data.PreferenceManager.getInstance(context.dataStore)


        return UserRepository.getInstance(pref, apiService)
    }
}