package com.dicoding.storyapp.modelview

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.storyapp.data.User
import com.dicoding.storyapp.data.UserRepository
import com.dicoding.storyapp.data.response.ResponseStory
import kotlinx.coroutines.launch

class ViewModelMain(private val userRepository: UserRepository): ViewModel() {

    private val _uploadResponse = MutableLiveData<ResponseStory>()

    val uploadResponse: LiveData<ResponseStory> get() = _uploadResponse

    private val _isLoading = MutableLiveData<Boolean>()

    val isLoading: LiveData<Boolean> get() = _isLoading


    fun getAllStories(token: String) {

        viewModelScope.launch {

            _isLoading.value = true

            try {

                val response = userRepository.getAllStories(token)

                _uploadResponse.value = response

                _isLoading.value = false

            } catch (e: Exception) {

                _isLoading.value = false

                e.printStackTrace()

            }

        }

    }


    fun getSession(): LiveData<User> {

        return userRepository.getSession()

    }


}