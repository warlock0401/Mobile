package com.dicoding.storyapp.modelview

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dicoding.storyapp.data.Injection
import com.dicoding.storyapp.data.UserRepository

class FactoryViewModel private constructor(private val repository: UserRepository): ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")

    override fun <T : ViewModel> create(modelClass: Class<T>): T {

        return when {

            modelClass.isAssignableFrom(ViewModelRegister::class.java) -> {

                ViewModelRegister(repository) as T

            }
            modelClass.isAssignableFrom(LoginViewModel::class.java) -> {

                LoginViewModel(repository) as T

            }
            modelClass.isAssignableFrom(ViewModelMain::class.java) -> {

                ViewModelMain(repository) as T

            }
            modelClass.isAssignableFrom(ViewModelAddStory::class.java) -> {

                ViewModelAddStory(repository) as T

            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)


        }

    }

    companion object {

        @Volatile
        private var INSTANCE: FactoryViewModel? = null

        @JvmStatic
        fun getInstance(context: Context): FactoryViewModel {
            if (INSTANCE == null) {

                synchronized(FactoryViewModel::class.java) {

                    INSTANCE = FactoryViewModel(Injection.provideRepository(context))

                }

            }

            return INSTANCE as FactoryViewModel


        }
    }
}