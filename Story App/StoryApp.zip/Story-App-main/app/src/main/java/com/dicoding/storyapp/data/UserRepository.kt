package com.dicoding.storyapp.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import com.dicoding.storyapp.data.response.AddResponseNew
import com.dicoding.storyapp.data.response.ResponseRegister
import com.dicoding.storyapp.data.response.ResponseStory
import com.dicoding.storyapp.data.api.ApiService
import okhttp3.MultipartBody
import okhttp3.RequestBody

class UserRepository (private val preferenceManager: com.dicoding.storyapp.data.PreferenceManager, private val apiService: ApiService) {
    suspend fun login(email: String, password: String) =

        apiService.login(email, password)


    suspend fun register(name: String, email: String, password: String) : ResponseRegister {

        Log.d("Register", "$name, $email, $password")

        return apiService.register(name, email, password)

    }

    suspend fun addStory(token: String, file: MultipartBody.Part, description: RequestBody) : AddResponseNew {

        return apiService.addStory(token, file, description)
    }


    suspend fun getAllStories(token: String) : ResponseStory {

        Log.d("Token", token)

        return apiService.getAllStories(token)

    }

    fun getSession() : LiveData<User> {

        return preferenceManager.getSession().asLiveData()

    }


    companion object {

        @Volatile
        private var instance: UserRepository? = null

        fun getInstance(

            userPreference: com.dicoding.storyapp.data.PreferenceManager,

            apiService: ApiService
        ): UserRepository =

            instance ?: synchronized(this) {

                instance ?: UserRepository(userPreference, apiService)

            }.also { instance = it }

    }
    
}
