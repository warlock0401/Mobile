package com.dicoding.storyapp.modelview

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.dicoding.storyapp.data.UserRepository
import com.dicoding.storyapp.data.response.ResponseError
import com.dicoding.storyapp.data.response.ResponseRegister
import kotlinx.coroutines.launch
import retrofit2.HttpException

class ViewModelRegister(private val userRepository: UserRepository) :ViewModel(){

    private val _registration = MutableLiveData<ResponseRegister>()

    val registration: LiveData<ResponseRegister> = _registration


    private val _isLoading = MutableLiveData<Boolean>()

    val isLoading: LiveData<Boolean> get() = _isLoading


    private val _isRegist = MutableLiveData<String>()

    val isRegist: LiveData<String> get() = _isRegist


    fun register(name: String, email: String, password: String)  {

        viewModelScope.launch {

            _isLoading.postValue(true)

            try {
                val response = userRepository.register(name, email, password)

                _registration.postValue(response)

                _isLoading.postValue(false)

            } catch (e: HttpException) {

                _isLoading.postValue(false)

                val jsonInString = e.response()?.errorBody()?.string()

                val errorBody = Gson().fromJson(jsonInString, ResponseError::class.java)

                val errorMessage = errorBody.message.toString()

                _isRegist.postValue(errorMessage)


            }

        }


    }


}